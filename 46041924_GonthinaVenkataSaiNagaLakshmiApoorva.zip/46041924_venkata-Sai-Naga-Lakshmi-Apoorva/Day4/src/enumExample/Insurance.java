package enumExample;
//Using Scanner class get insurance details from User and store those details in insurance Object. 
//Set values using setter methods. And display the insurance Object(Override toString method).
import java.util.*;
public class Insurance 
{
	public static void main(String[] args)
	{
		
	 System.out.println("Enter the Insurance policy Id. ");
	 Scanner sc =new Scanner(System.in);
	 InsuranceDetails ind = new InsuranceDetails();
	 int id=sc.nextInt();
	 ind.setId(id);
	 System.out.println("Enter the type of Insurance: ");
	 String type =sc.next();
	 ind.setType(type);
	 System.out.println("Enter the Name of Customer: ");
	 String name =sc.next();
	 ind.setName(name);
	 System.out.println("Enter the age of the customer: ");
	 int age=sc.nextInt();
	 ind.setAge(age);
	 System.out.println(ind);
	 sc.close();
	}
}
