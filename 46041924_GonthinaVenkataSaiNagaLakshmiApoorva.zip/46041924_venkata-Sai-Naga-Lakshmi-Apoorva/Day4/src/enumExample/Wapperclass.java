package enumExample;
public class Wapperclass 
{
	public static void main(String args[]) 
    { 
		System.out.println("-----------------Primitive to obj------------------"); 
        @SuppressWarnings("deprecation")
		Integer intobj = new Integer(10); 
        System.out.println("Integer object intobj:  " + intobj); 
        @SuppressWarnings("deprecation")
		Float floatobj = new Float(20.6f); 
        System.out.println("Float object floatobj:  " + floatobj); 
        @SuppressWarnings("deprecation")
		Double doubleobj = new Double(20d); 
        System.out.println("Double object doubleobj:  " + doubleobj); 
        @SuppressWarnings("deprecation")
		Character charobj= new Character('a'); 
        System.out.println("Character object charobj:  " + charobj); 
        System.out.println("-------------------------obj to primitive---------------"); 
        int iv = intobj; 
        float fv = floatobj; 
        double dv = doubleobj; 
        char cv = charobj;  
        System.out.println("int : " + iv); 
        System.out.println("float : " + fv); 
        System.out.println("double : " + dv); 
        System.out.println("char : " + cv); 
    } 
} 

