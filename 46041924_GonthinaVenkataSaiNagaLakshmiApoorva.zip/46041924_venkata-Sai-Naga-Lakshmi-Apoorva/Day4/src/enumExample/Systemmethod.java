package enumExample;
public class Systemmethod
{
	public static void main(String args[])
	{
		System.out.println("current time in milli is: "+System.currentTimeMillis());
	}
}
