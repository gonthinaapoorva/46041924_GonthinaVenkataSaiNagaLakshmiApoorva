package enumExample;
//Create fullname as variable of string type. Display the length, and use substring, and check do the string is null or not?
public class Stringprog 
{
	public static void main(String args[])
	{
		String fullName = "gonthina venkata sai naga lakshmi apoorva";
		int length = fullName.length();
		System.out.println("The length of the name  "+fullName+ " is "+length);
		String substr = fullName.substring(0, 5);
		System.out.println("substring is "+substr);
		if (fullName.length() == 0)
		{
			System.out.println("String is Empty");
		}
		else
		{
		    System.out.println("String is not Empty");
		}
	}
}
