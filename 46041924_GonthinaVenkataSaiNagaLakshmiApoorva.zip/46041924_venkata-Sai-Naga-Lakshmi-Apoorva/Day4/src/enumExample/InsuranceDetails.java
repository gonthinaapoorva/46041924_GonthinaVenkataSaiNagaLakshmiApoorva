package enumExample;

public class InsuranceDetails 
{
		int id;
		String type;
		int age;
		String name;
		public int getId() {
		return id;
		}
		public void setId(int id) {
		this.id = id;
		}
		public String getType() {
		return type;
		}
		public void setType(String type) {
		this.type = type;
		}
		public int getAge() {
		return age;
		}
		public void setAge(int age) {
		this.age = age;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String toString()
		{
			
			return "Id is "+getId()+"\nType of Insurance: "+getType()+"\nName of the customer: "+getName()+"\nAge of the customer: "+getAge();
			
		}
}