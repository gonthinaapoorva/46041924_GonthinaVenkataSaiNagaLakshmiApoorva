package Demo;

public class Executor 
	{

		public static void main(String[] args) {
			new Derived();
		}

	}

