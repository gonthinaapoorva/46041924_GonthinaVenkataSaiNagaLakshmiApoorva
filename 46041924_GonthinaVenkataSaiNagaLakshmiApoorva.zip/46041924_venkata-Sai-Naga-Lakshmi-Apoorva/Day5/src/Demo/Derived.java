package Demo;

public class Derived extends Base {

	Derived()
	{
		var_default=10;
		var_public=20;
		var_protected=40;
		//var_private = 60;(private variable )
		method_default();
		method_public();
		method_protected();
		//method_private();(private method)
	}
	
}

