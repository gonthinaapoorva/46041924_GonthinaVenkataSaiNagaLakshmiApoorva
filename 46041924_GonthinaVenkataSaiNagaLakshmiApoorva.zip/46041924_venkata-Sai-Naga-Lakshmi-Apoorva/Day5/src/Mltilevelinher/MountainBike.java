package Mltilevelinher;

class MountainBike extends Bike
{
	    double maxEleva;
}
