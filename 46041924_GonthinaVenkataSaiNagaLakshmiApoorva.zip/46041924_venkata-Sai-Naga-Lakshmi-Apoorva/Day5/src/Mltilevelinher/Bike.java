package Mltilevelinher;

public class Bike extends RegVehicle
{
	    boolean hasHelmet;
}
