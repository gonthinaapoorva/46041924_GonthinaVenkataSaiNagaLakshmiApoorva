package Mltilevelinher;

public class Car extends RegVehicle
{
	boolean hasAC;
}
