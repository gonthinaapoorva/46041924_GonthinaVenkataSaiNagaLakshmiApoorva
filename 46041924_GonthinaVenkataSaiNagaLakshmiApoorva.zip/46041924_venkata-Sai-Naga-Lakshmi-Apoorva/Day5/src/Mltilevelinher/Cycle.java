package Mltilevelinher;

public class Cycle extends Vehicle
{
	    boolean hasBackSeat;
}
