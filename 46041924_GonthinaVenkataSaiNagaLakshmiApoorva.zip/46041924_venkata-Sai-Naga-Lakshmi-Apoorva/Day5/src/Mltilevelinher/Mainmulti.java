package Mltilevelinher;

public class Mainmulti 
{
   public static void main(String arg[])
   {
	   MountainBike mb = new MountainBike();
	   mb.noOfWheels = 2;
	   mb.regNo = "APXX WWW";
	   mb.hasHelmet = true;
	   mb.maxEleva = 3000.0;
	   System.out.print("Mountain Bike with registration Number " + mb.regNo);
	   System.out.println(" is supported till the elevation of " + mb.maxEleva + " feet.");    
	}
}

