package Mltilevelinher;

public class RegVehicle extends Vehicle 
{
	String regNo;
}
