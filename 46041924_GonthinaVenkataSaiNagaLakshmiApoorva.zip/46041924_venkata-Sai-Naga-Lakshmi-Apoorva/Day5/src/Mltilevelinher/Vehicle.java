package Mltilevelinher;

public class Vehicle 
{
	    int noOfWheels;
}
