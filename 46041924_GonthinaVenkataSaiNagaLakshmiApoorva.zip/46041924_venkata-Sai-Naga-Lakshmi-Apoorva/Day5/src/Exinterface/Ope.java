package Exinterface;

interface Ope 
{
	abstract void result();
}
