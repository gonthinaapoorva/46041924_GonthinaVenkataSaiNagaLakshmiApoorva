package Exinterface;

class Ex implements Ope
{
	public void result()
	{
		System.out.println("result method invoked");
	}
}
public class Sub
{
	public static void main(String args[])
	{
		Ope o = new Ex();
		o.result();
	}
}

