package Abstructex;

class Ex extends Operation
{
	public void result()
	{
		System.out.println("result method invoked");
	}
}
public class Add
{
	public static void main(String args[])
	{
		Operation o = new Ex();
		o.result();
	}
}
