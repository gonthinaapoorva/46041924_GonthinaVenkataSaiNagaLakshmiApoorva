package Abstructex;

abstract class Operation 
{
	abstract void result();
}
