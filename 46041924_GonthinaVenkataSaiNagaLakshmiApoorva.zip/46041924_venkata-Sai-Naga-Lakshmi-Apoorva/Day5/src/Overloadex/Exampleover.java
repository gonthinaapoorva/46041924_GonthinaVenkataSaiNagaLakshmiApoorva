package Overloadex;

class Areas
{
	public void area(int a)
	{
		int x = a * a;
		System.out.println(x);
	}
	public void area(int l , int b)
	{
		int z = l*b;
		System.out.println(z);
	}
}

public class Exampleover
{
	public static void main(String args[])
	{
		Areas a = new Areas();
		
		int y = 10;
		a.area(y);
		int l =5;
		int b =20;
		a.area(l, b);
	
	}
	
}
