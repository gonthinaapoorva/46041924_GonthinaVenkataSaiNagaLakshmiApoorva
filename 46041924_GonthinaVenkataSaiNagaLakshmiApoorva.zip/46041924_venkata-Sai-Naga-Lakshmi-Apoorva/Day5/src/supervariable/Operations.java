package supervariable;

class Operations 
{
	int a = 2;
	int b = 10;
	public void display()
	{
		System.out.println("Parent class display method");
	}
}
