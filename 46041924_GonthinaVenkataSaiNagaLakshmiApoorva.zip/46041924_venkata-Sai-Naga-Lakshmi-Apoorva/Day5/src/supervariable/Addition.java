package supervariable;

public class Addition extends Operations 
{
	public void add(int x , int y)
	{
		int s = super.a;
		int t = super.b;
		System.out.println("parent class 'a' value: "+s);
		System.out.println("parent class 'b' value: "+t);
		System.out.println("Addition of super class values :"+(s+t));
		System.out.println("child class add method value:"+(x+y));
		
	}
	
}
