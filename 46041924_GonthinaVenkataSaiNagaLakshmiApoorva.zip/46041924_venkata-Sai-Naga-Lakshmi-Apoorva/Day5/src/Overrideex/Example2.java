package Overrideex;

public class Example2 extends Example1
{
	public void display()
	{
		System.out.println("child display is invoked");
	}
}
