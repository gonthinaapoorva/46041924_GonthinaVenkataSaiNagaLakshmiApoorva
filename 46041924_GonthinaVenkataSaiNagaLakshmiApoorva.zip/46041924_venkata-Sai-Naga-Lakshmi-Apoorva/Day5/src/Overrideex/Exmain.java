// when subclass and super class have same method-overriding
package Overrideex;

public class Exmain 
{
	public static void main(String args[])
	{
		Example1 ex = new Example1();
		Example2 example = new Example2();
		ex.display();
		example.display();
		
	}
}
