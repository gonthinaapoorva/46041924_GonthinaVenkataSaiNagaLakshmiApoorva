package Overrideex;

public class Example1
{
	public void display()
	{
		System.out.println("Parent class display method");
	}
}
