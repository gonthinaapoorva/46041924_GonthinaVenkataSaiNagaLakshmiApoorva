package Inheritancr;

public class Fruit
{
	public void display()
	{
		System.out.println(" is a fruit");
	}
}
