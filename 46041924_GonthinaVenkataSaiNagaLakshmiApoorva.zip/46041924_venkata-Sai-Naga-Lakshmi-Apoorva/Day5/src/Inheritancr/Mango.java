package Inheritancr;

public class Mango extends Fruit
{
	public void mangoFruit()
	{
		System.out.print("Mango");
	}
}
