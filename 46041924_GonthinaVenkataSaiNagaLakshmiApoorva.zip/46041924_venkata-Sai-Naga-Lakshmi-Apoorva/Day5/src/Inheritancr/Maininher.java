package Inheritancr;
public class Maininher 
{
	public static void main(String args[])
	{
		Fruit f = new Fruit();
		Apple a = new Apple();
		Mango m = new Mango();
		a.appleFruit();
		f.display();
		m.mangoFruit();
		f.display();
	}
}
