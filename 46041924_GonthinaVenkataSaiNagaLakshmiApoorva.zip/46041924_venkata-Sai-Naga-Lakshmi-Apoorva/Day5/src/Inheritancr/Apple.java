package Inheritancr;

public class Apple extends Fruit
{
	public void appleFruit()
	{
		System.out.print("Apple");
	}
}
