//Write pgm to display the current date , day, month, year etc.
package lesson4;

import java.time.LocalDate;
import java.time.Month;
public class Task5 
{
	   public static void main(String args[])
	   {
	      LocalDate currentdate = LocalDate.now(); //To get the current date
	      System.out.println("Current date: "+currentdate);
	     
	      int currentDay = currentdate.getDayOfMonth(); //To Get the current day
	      System.out.println("Current day: "+currentDay);
	     
	      Month currentMonth = currentdate.getMonth();//To get the current month
	      System.out.println("Current month: "+currentMonth);
	     
	      int currentYear = currentdate.getYear();// To get the current year
	      System.out.println("Current year: "+currentYear);
	   }
}
