package lesson4;
import java.util.*;
public class Task6 
{ 
	public static void main(String args[])
	{
		Scanner scanner =new Scanner(System.in);
		int n = scanner.nextInt();
		scanner.close();
		if(n%2==0)
		{
			System.out.println(n+" is even");
		}
		else
		{
			System.out.println(n+" is odd");
		}
	}
}
