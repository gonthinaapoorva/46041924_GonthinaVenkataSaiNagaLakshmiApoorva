//Write pgm using static variable and static method for Cinema Hall.
package lesson4;
public class Task4 
{
	String name="Bahubali";
	static int ticketCost=50;//static variable
	int noofTickets = 5;
	public void details()
	{
		System.out.println("Movie Name :"+name);
		System.out.println("Ticket cost :"+ticketCost);
		System.out.println("No of Tickets :"+noofTickets);
		int x = totalCost(noofTickets);
		System.out.println("The total cost :"+x);
	}
	public static int totalCost(int noofTickets)//static method
	{ 
			int result= noofTickets*ticketCost;//if you don't add parameter then we can't refer no of tickets as it is non-static variable 
			return result;
	}
	public static void main(String args[])
	{
		Task4 task = new Task4();
		task.details();
	}
}
