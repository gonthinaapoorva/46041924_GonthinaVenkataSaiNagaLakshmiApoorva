package lesson4;
class Demo
{
	private int a=2;//private access modifier enables the variable to access only in the same class
	public int add()// can be accessed from any other class
	{
		int b = 3;
		int sum= a+b;
		return sum;
	}
}
public class Task3
{
	public static void main(String args[])
	{
		Demo d = new Demo();
		int result = d.add();
		System.out.println(result);
		//System.out.println(a);
	}
	
}
