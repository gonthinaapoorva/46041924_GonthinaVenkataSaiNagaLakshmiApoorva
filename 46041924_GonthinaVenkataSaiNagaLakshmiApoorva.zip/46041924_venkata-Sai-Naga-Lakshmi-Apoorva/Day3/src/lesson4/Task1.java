//Create a package and write some basic program. 2 class with same name but in different packages
package lesson4;
public class Task1 
{
	public static void main(String args[])
	{
		int a=2;
		int b=3;
		int sum = a+b;
		System.out.println("sum :"+sum);
	}
}

