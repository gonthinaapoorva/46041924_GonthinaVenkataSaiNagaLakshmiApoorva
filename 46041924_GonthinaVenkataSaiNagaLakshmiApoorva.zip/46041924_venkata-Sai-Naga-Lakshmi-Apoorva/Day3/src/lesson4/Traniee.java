package lesson4;
import java.util.*;
public class Traniee 
{
	String mail_Id = "apoorva@gmail.com";//instance variable
	public float salary(int no)//single parameter
	{
		float salary = no*1000;
		return salary;
	}
	public void details(int empId, String name, Long phno, float x)//multiple parameters
	{
		System.out.println("The details of the employee :");
		System.out.println("Emp_Id : "+empId);
		System.out.println("Name of the employee : "+name);
		System.out.println("Phone number : "+phno);
		System.out.println("Mail_id: "+mail_Id);
		System.out.println("Salary : "+x);
	}
	public void batch()//no parameter
	{
		System.out.println("----------JEE With React-------------");
	}
	public static void main(String args[])
	{
		Traniee t = new Traniee();
		Scanner sc = new Scanner(System.in);
		System.out.println("Add the details of the employee:");
		int empId = sc.nextInt();
		String name = sc.next();
		Long phno = sc.nextLong();
		System.out.println("Enter no of days he/she worked: ");
		int no = sc.nextInt();
		float x = t.salary(no);// returned value from salary method and printed the value
		System.out.println("The salary is: "+x);
		t.batch();
		t.details(empId, name, phno, x);
		sc.close();
	}
}
