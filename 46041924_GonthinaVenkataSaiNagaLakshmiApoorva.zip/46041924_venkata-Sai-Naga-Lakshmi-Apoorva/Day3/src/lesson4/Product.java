//Constructor Chain for Product class
package lesson4;

public class Product 
{
	Product()
	{
		this(123,"Powder",55);
		
	}
	Product(int id,String name,float cost)
	{
		System.out.println("----------The product details are----------");
		System.out.println("Product Id :"+id);
		System.out.println("Product name :"+name);
		System.out.println("Product cost :"+cost);
		
	}
	public static void main(String args[])
	{
		Product product = new Product();
		Product product2 = new Product(456,"Maggi",20);
		
	}
}
