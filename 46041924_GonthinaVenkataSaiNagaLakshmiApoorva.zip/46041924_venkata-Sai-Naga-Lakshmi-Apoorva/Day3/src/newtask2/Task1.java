package newtask2;
public class Task1 
{
	public static void main(String args[])
	{
		int a =5;
		int b = 2;
		System.out.println(a-b);
	}
}
