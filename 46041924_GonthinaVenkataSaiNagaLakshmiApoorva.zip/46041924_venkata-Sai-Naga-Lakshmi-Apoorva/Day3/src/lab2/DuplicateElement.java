package lab2;

import java.util.*;

public class DuplicateElement
{
	public static void removeDuplicateElements(int a[], int n)
	{  
		Arrays.sort(a);
		int[] b = new int[n];
		for(int i =0;i<n-1;i++)
		{
	        for (int j = 0; j < i; j++) 
	        {
	            if (a[i] == a[j]) 
	            {
	                break; 
	            }
	            if (i == j) 
	            System.out.print( a[i] + " "); 
	        } 
	    } 
	
		for (int i =0;i<n;i++)
		{
			System.out.println(b[i]);
		}
		
	}

	public static void main (String[] args)
	{  
		Scanner sc =new Scanner(System.in);
		int l = sc.nextInt();
		int[] a = new int[l];
		for(int i=0;i<l;i++)
		{
			a[i]=sc.nextInt();
		} 
	     removeDuplicateElements(a, l);   
	}
}
