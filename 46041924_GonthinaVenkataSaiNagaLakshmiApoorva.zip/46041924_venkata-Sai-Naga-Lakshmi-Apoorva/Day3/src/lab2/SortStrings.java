//Create a method that can accept an array of String objects and sort in alphabetical order. 
//The elements in the left half should be completely in uppercase and the elements in the right half should be completely in 
//lower case.Return the resulting array.
//Note: If there are odd number of String objects, then (n/2) +1 elements should be in UPPPERCASE

package lab2;
import java.util.Scanner;
public class SortStrings 
{
	public static void main(String[] args) 
	{
		int count;
		String temp;
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter number of strings you would like to join:");
		count = scan.nextInt();
		String str[] = new String[count];
		System.out.println("Enter the Strings one by one:");
		for(int i = 0; i <count; i++)
		{
			str[i] = scan.next();
		}
		scan.close();
		for (int i = 0; i<count; i++) 
		{
			for (int j = i + 1; j<count; j++) 
			{ 
				if (str[i].compareTo(str[j])>0) 
		        {
					temp = str[i];
					str[i] = str[j];
					str[j] = temp;
		        }
		    }
		}
		System.out.print("Strings in Sorted Order:");
		for (int i = 0; i<= count - 1; i++) 
		{
			System.out.print(str[i] + ", ");
		}
	}
}

