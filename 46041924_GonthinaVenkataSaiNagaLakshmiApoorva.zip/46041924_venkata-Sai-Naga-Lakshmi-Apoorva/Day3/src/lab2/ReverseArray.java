package lab2;
import java.util.*;
public class ReverseArray 
{
	public static void main(String[] args)
	{  
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] a = new int[n];
		
		for(int i =0;i<n;i++)
		{
			a[i] = sc.nextInt();
		}
		getSorted(a,n);
		sc.close();
	}
	public static void getSorted(int[] a,int n)
	{
		Arrays.sort(a);
		int j=0;
		int[] b = new int[n];
		System.out.println("Array in reverse order: ");  
		for (int i = a.length-1; i >= 0; i--) 
		{  
			b[j] = a[i];
			j++;
		}
		Arrays.sort(b);
		for(int i=0;i<n;i++)
		{
			System.out.println(b[i]);
		}
	}  
}
