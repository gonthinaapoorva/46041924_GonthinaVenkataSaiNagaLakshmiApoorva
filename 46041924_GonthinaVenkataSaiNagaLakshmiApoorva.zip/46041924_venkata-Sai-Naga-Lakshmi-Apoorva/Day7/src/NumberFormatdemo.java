//converting string to integer
	import java.util.Scanner;

	public class NumberFormatdemo {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        try
	        {
		        String input = scanner.nextLine();
		        int number = Integer.parseInt(input); // an exception is possible here!
		        System.out.println(number + 1);
	        }
	        catch(Exception e)
	        {
	        	System.out.println(e);
	        }
	        scanner.close();
	    }
	}
