public class NullpointerEx
{
	public static void main(String args[])
	{
		String a = null;
		try
		{
			int length = a.length();
			System.out.println(length);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
