
public class IllegalArgex 
{
	public static void main(String args[])
	{
		 long amount = 0;
			 if (amount <= 0) 
			 {
		            throw new IllegalArgumentException("Incorrect sum " + amount);
		     }
		        
		     if (amount >= 100_000_000L) 
		     {
		            throw new IllegalArgumentException("Too large amount");
		     }  
		}
	}
