import java.util.*;
public class ArrayIndexex
{
	public static void main(String args[])
	{
		int[] array = new int[5];
		Scanner sc = new Scanner(System.in);
		for(int i = 0;i< array.length;i++)
		{
			array[i]= sc.nextInt();
		}
		try
		{
			for(int i=0;i< array.length+1;i++)
			{
				System.out.println(array[i]);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
}
