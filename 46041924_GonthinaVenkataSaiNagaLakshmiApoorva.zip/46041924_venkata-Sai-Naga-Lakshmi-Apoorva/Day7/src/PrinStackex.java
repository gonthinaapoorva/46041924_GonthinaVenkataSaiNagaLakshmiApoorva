public class PrinStackex 
{
	public static void main(String args[])
	{  
		try
		{  
			int data=100/0;  
			data= data + 1;
		}
		catch(ArithmeticException e)
		{
			e.printStackTrace();
		}  
	}  	
}
