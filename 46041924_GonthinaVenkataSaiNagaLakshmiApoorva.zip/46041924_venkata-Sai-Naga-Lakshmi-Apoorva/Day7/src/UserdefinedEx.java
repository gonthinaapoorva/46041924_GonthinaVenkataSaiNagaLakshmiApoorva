import java.util.*;
public class UserdefinedEx extends Exception
{
	public static double sqrt(double x) 
	{
		if(x<0)
	    {
	        throw new IllegalArgumentException("Expected non-negative number, got " +x);
	    }
	    else
	    {
	         return Math.sqrt(x);
	    }
	 }
	 public static void main(String[] args) 
	 {
		 Scanner sc =new Scanner(System.in);
	     String value = sc.nextLine();
	     try 
	     {
	    	 double res = sqrt(Double.parseDouble(value));
	         System.out.println(res);
	     } 
	     catch (IllegalArgumentException e) 
	     {
	          System.out.println(e.getMessage());
	     }
	     sc.close();
	  }
}
