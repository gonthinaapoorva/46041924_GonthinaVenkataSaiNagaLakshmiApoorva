public class StringindexEx 
{
	public static void main(String[] args) 
	{
		try
		{
			String str = "Welcome to Tutorials Point.";
			System.out.println("Length of the String is: " + str.length());
			System.out.println("Length of the substring is: " + str.substring(28));
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
