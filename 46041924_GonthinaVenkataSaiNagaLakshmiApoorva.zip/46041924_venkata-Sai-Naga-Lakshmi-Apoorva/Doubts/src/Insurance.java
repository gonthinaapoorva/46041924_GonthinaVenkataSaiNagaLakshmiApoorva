
public class Insurance 
{
	int policy_No;
	  long contact_No;  
	String typeOfInsurance;

	public String toString()
	{                            //overriding the toString() method  
	 return(getPolicy_No()+" "+getContact_No()+" "+getTypeOfInsurance());  
	}
	public int getPolicy_No() {
	return policy_No;
	}
	public void setPolicy_No(int policy_No) {
	this.policy_No = policy_No;
	}
	public String getTypeOfInsurance() {
	return typeOfInsurance;
	}
	public void setTypeOfInsurance(String typeOfInsurance) {
	this.typeOfInsurance = typeOfInsurance;
	}
	public long getContact_No() {
	return contact_No;
	}
	public void setContact_No(long contact_No) {
	this.contact_No = contact_No;
	}

	}
}
