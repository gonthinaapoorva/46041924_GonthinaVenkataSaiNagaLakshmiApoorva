
import java.util.ArrayList;
import java.util.Scanner;
public class Details
{
	static int count=0;
	public static void main(String[] args)
	{
		int ch;
		Scanner sc=new Scanner(System.in);
		ArrayList<Project> details=new ArrayList<Project>();
		do
		{
			System.out.println("1. Add collection");
			System.out.println("2. Delete collection");
			System.out.println("3. Display collection");
			System.out.println("4. Exit");
			System.out.println("Enter your choice:");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1: count++;
					if(count>3)
					{
						try
						{
							CollectionOverload co=new CollectionOverload("Cannot add more than 3 collections");
							throw co;
						}
						catch(CollectionOverload c)
						{
							System.out.println(c);
						}
					}
					else
					{
						Project e=new Project();
						System.out.println("Enter first name:");
						String fname=sc.next();
						if(fname.matches( "[A-Z]{1}[a-z]{2,}$" ))
						e.setFname(fname);
						System.out.println("Enter last name:");
						String lname=sc.next();
						if( lname.matches( "[A-Z]{1}[a-z]{2,}$" ))
						e.setLname(lname);
						System.out.println("Enter mobile brand");
						String brand=sc.next();
						if(brand.matches("[A-Z]{1}[a-z]{2,}$"))
						e.setMobBrand(brand);
						System.out.println("Enter price:");
						double price=sc.nextDouble();
						if(price>1000)
						e.setPrice(price);
						System.out.println("Enter quantity:");
						int qty=sc.nextInt();
						if(qty>0)
						e.setQty(qty);
						//add object inside collection
						details.add(e);
					}
					break;
					case 2: System.out.println("Enter mobile brand name to delete that collection:");
							String bname=sc.next();
			// to check from arraylist if the brand name exists.
			// if exists count-- and delete that collection
			// else -- collection unavailable
							int flag=0;
							for(int i=0;i<details.size();i++)
							{
								String comp=details.get(i).getMobBrand();
								if(comp.equals(bname))
								{
									count--;
									details.remove(i);
									flag=1;         //to show that the element has been found and deleted.
								}
							}
							if(flag==1)	
							{
								System.out.println("The collection with brand name "+bname+" removed successfully.");
							}
							else
							{
								System.out.println("Collection Unavailable");
							}

					 break;
					 case 3: for (int i = 0; i < details.size();i++)  // to call the display function of array list
					 		{      
						 		System.out.println(details.get(i));
					 		}  
					 		break;
					 case 4: System.out.println("Thank you for using the application");
					 		System.exit(0);
				}
			}
			while(ch!=4);
			}
		}
		class CollectionOverload extends Exception {
		CollectionOverload()
		{
			System.out.println("Cannot add more than 3 elements");
		}
		CollectionOverload(String message)
		{
			super(message);
		}

	}

