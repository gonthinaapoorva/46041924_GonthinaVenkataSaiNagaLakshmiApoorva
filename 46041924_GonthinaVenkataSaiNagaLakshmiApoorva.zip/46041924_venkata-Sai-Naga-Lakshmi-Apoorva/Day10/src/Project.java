public class Project 
{
	private String fname;
	private String lname;
	private String mobBrand;
	private double price;
	private int qty;
	public String getFname()
	{
		return fname;
	}
	public void setFname(String fname)
	{
		this.fname = fname;
	}
	public String getLname()
	{
		return lname;
	}
	public void setLname(String lname)
	{
		this.lname = lname;
	}
	public String getMobBrand()
	{
		return mobBrand;
	}
	public void setMobBrand(String mobBrand)
	{
		this.mobBrand = mobBrand;
	}
	public double getPrice()
	{
		return price;
	}
	public void setPrice(double price)
	{
		this.price = price;
	}
	public int getQty()
	{
		return qty;
	}
	public void setQty(int qty)
	{
		this.qty = qty;
	}
	@Override
	public String toString()
	{
		return "Entity [fname=" + fname + ", lname=" + lname + ", mobBrand=" + mobBrand + ", price=" + price + ", qty="
	+ qty + "]";
	}

}
