package assignment2;

public class Details
{
	private String name;
	public Details(String name)
	{
		this.name=name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean equals (Object obj) 
	{
		if (obj == null)
			return false;
		if (!(obj instanceof Details))
			return false; 
		if (obj == this)
			return true;
		return this.getName() ==((Details) obj).getName();
	}
	
	public int hashCode() {
		return name.hashCode();
	}
	
}
