package assignment2;

public class Customer1 
{
	String name;
	Customer1(String name)
	{
		this.name = name;
	}
}

