package assignment2;
//normal program
import java.util.*;
public class Custmain
{
	public static void main(String[] args)
	{
		Details c = new Details("Appu");
		Details c1 = new Details("Appu");
		boolean result = c.equals(c1);
		System.out.println("comparing two objects with equal():"+result);
		System.out.println("hashcode of object c:"+c);
		System.out.println("hashcode of object c1:"+c);
		/*List<Details> d = new ArrayList<Details>();
		d.add(c);
		System.out.println("ArrayList size = " + d.size());
		System.out.println("ArrayList contains Appu = " + d.contains(new Details ("Appu")));*/
		
	}
}
