//Create a method which accepts a hash map and return the values of the map in sorted order as a List.
package lab6;
import java.util.*;
public class Hashmapprog1
{
	private List<String> li = new ArrayList<String>();
	public List<String> getValue(HashMap<Integer, String> hash_map)
	{
			for (String value : hash_map.values())
			{
				li.add(value) ;
			}
			Collections.sort(li);
		return li;
	}
}
