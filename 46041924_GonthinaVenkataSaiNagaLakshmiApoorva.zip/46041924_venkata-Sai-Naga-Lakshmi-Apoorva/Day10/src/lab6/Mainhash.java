package lab6;

import java.util.HashMap;

public class Mainhash 
{
	public static void main(String args[])
	{
		HashMap<Integer, String> hash_map = new HashMap<Integer, String>(); 
		Hashmapprog1 h = new Hashmapprog1();
		hash_map.put(1, "Gonthina"); 
	    hash_map.put(2, "venkata"); 
	    hash_map.put(3, "sai"); 
	    hash_map.put(4, "Naga"); 
	    hash_map.put(5, "Lakshmi"); 
	    hash_map.put(6, "Apoorva");
	    System.out.println(h.getValue(hash_map));
	}
}
