package lab6;

import java.util.*;


public class Eli
{
	public List <Integer> voterList(HashMap<Integer,Integer> hash1)
	{
		List<Integer> li = new ArrayList<Integer>();
		for (int i : hash1.keySet()) 
		{
			if(hash1.get(i)>18)
			{
				li.add(i);
			}
		}
		return li;
	}
}

