import java.util.*;
public class Listofoperations
{
	public static void main(String args[])
	{
		ArrayList<Integer> li2 = new ArrayList<Integer>();
		ArrayList<Integer> li1 = new ArrayList<Integer>();
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int m = sc.nextInt();
		int x = sc.nextInt();
		li2= makeArrayListInt(n);
		li1 = reverseList((ArrayList<Integer>) li2);
		li2= changeList((ArrayList<Integer>) li1 ,m,x);
		System.out.println(li2);
		sc.close();
	}
	public static ArrayList<Integer> makeArrayListInt(int n)
	{
		ArrayList<Integer> li1 = new ArrayList<Integer>();
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<n;i++)
		{
			int s = sc.nextInt();
			li1.add(s);
		}
		return li1;
	}
	public static ArrayList<Integer> reverseList(ArrayList<Integer> li)
	{
		Collections.reverse(li);
		return li;
	}
	public static ArrayList<Integer> changeList(ArrayList<Integer> li ,int m,int x)
	{
		for(int i=0;i<li.size();i++)
		{
			if(li.get(i)== m)
			{
				li.set(i, x);
			}
		}
		return li;
	}

}
