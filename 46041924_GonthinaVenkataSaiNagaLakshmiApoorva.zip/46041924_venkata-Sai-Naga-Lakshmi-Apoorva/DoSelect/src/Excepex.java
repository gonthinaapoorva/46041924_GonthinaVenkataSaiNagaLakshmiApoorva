import java.util.*;
public class Excepex
{
    static String str1;
    static String str2;
    static String op;
    public Excepex(String str1,String str2,String op)
    {
    	this.str1=str1;
    	this.str2=str2;
    	this.op=op;
    }
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        String str1 = sc.nextLine();
        String str2 = sc.nextLine();
        String op = sc.nextLine();
        System.out.println(handleException(str1,str2,op));
        sc.close();
    }
    public static String doOperation(String str1,String str2,String op) throws NullPointerException,OperatorException
    {
    	switch(op)
		{
    		
			case "+":
				str1 = str1.concat(str2);
				return str1;
			case "-":
				Excepex.str1 = str1;
				return str1;
		}
    	return str1;
    }
    public static String handleException(String str1,String str2,String op)
    {
        try
        {
            if(str1.length()==0 || str2.length()==0)
            {
                throw new NullPointerException();         
            }
            else
            {
            	try
            	{
	            	if(op.charAt(0)=='+' || op.charAt(0)=='-')
	            	{
	            		return doOperation(str1,str2,op);
	            		
	            	}
	            	else
	            	{
	            		throw new OperatorException("Exception Occured");
	            	}
	            	 
            	}
            	catch(OperatorException e)
                {
                	str1 = e.getMessage();
                	return str1;
                }
            }
        }
        catch(NullPointerException e)
        {
            str1 = "Null values found";
            return str1;
        }
    }
    static class OperatorException extends Exception
    { 
    	public OperatorException(String s)
    	{
    		super(s);
    	}
    } 
}
