import java.util.*;
public class Labprog5 
{
	public int Sum(int n)
	{
		int sum1=0;
		for(int i=1;i<=n;i++)
		{
			if(i%3==0 || i%5==0)
			{
				sum1=sum1+i;
			}
		}
		return sum1;
	}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n =sc.nextInt();
		Labprog5 obj = new Labprog5();
		int x= obj.Sum(n);
		System.out.println(x);
		sc.close();
		
	}
}
