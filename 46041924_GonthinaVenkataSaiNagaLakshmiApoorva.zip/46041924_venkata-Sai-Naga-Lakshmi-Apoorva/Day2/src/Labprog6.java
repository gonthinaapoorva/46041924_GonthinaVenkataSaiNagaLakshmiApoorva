import java.util.*;
public class Labprog6 
{
	public int calculateDifference(int n)
	{
		int sum;
		int sum1 = 0;
		int sum2 = 0;
		for(int i=1;i<=n;i++)
		{
			int y = i*i;
			sum1 = sum1+i;
			sum2 = sum2+y;
		}
		int sum3 = sum1 * sum1;
		sum = sum2 - sum3;
		return sum;
	}
	public static void main(String args[]) 
	{
		Scanner sc = new Scanner(System.in);
		int n =sc.nextInt();
		Labprog6 lb = new Labprog6();
		int x = lb.calculateDifference(n);
		System.out.println(x);
		sc.close();
		
	}
	
}
