package Lesson3;
import java.util.*;
public class Trafficsignal 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the signal colour");
		String signal = sc.nextLine();
		sc.close();
		switch (signal) 
		{
			case "RED":
				System.out.println("STOP");
				break;
			case "YELLOW":
				System.out.println("READY");
				break;
			case "Green":
				System.out.println("GO");
				break;
			default:
				System.out.println("Enter valid signal");
			}
		}
	}

