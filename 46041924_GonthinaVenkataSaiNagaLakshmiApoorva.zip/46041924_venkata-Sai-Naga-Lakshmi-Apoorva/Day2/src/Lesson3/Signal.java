package Lesson3;
import java.util.*;
public class Signal {
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the signal colour");
		String colour=sc.nextLine();
		sc.close();
		switch(colour)
		{
		case "red":
			System.out.println("STOP");
			break;
		case "yellow":
			System.out.println("WAIT");
			break;
		case "green":
			System.out.println("GO");
			break;
		default:
			System.out.println("invalid input");
			break;	
		}
	}
}