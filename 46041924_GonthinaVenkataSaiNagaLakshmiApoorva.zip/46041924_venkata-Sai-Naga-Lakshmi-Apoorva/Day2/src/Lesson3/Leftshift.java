package Lesson3;

public class Leftshift 
{
	public static void main(String[] args) 
	{
		  int i;
		    int num = 16;
		    for(i=0; i<4; i++) 
		    {
		      num = num << 1;
		      System.out.println(num);
		    }
	}

}
