package Lesson3;

public class Prefixpostfix 
{
	public static void main(String[] args) 
	{
		  int num1 = 5;
		    int num2 = 10;
		    int num3 = 0;

		    num3 = --num1 + num2--;
		    System.out.println(num1);
		    System.out.println(num2);
		    System.out.println(num3);
		  
	}

}
