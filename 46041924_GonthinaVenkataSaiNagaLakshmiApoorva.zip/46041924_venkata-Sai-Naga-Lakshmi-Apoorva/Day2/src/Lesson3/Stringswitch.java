package Lesson3;

public class Stringswitch 
{
	public static void main(String[] args) 
	{
		String currentDay = args[0];
		switch (currentDay) 
		{
		case "MONDAY":
			System.out.println("Headache");
			break;
		case "TUESDAY":
			System.out.println("Second stage");
			break;
		case "WEDNESDAY":
			System.out.println("boring");
			break;
		case "THURSDAY":
			System.out.println("getting better");
			break;
		case "FRIDAY":
			System.out.println("weekend mode");
			break;
		case "SATURDAY":
			System.out.println("weekend");
		case "SUNDAY":
			System.out.println("Holiday........");
			break;

		}
	}

}
