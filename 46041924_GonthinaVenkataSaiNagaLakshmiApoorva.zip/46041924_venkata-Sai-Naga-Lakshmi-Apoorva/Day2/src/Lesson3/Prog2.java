package Lesson3;
public class Prog2 {
	
		public static void main(String[] args) {
			
			int i = 0;
		    switch (i) 
		    {
		    case 0:
		    	System.out.println("i is 0");
		    	break;
		    case 1:
		        System.out.println("i is 1");
		        break;
		    case 2:
		        System.out.println("i is 2");
		        break;
		    default:
		        System.out.println("Free flowing switch example!");
		    }
		}
	}

