package Lesson3;

public class Relationalandlogic 
{
	public static void main(String[] args) 
	{
		    int i = 10;
		    int j = 12;
		    System.out.println(i);
		    System.out.println(j);
		    System.out.println(i > j);
		    System.out.println(i < j);
		    System.out.println(i >= j);
		    System.out.println(i <= j);
		    System.out.println(i == j);
		    System.out.println(i != j);
		    System.out.println((i < 10) && (j < 10));
		    System.out.println((i < 10) || (j < 10));
	}
}

