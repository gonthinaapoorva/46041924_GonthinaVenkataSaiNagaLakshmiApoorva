package Lesson3;

public class Assignment 
{
	public static void main(String args[]) 
	{
	    int a = 1;
	    int b = 2;
	    int c = 3;
	    a = a+ 5;
	    b =b * 4;
	    c = c + a * b;
	    c = c % 6;
	    System.out.println("a = " + a);
	    System.out.println("b = " + b);
	    System.out.println("c = " + c);
	  }

}

