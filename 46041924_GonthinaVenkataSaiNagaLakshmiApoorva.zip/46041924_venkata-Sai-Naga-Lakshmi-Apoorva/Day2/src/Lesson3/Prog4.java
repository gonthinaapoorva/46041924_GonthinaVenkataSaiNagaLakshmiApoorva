package Lesson3;

public class Prog4 
{
	public static void main(String[] args) {
		int i=0;
		do
		{
	        System.out.println(i + " ");
	        i++;
	    }
		while(i<5 && i>0);
	}
}
