import java.util.*;
public class Labprog7 
{
	public boolean checkNumber(int n)
	{
		int i = 999;
		boolean sum = true;
		outer:
			while(n!=0)
			{
				int y = n % 10;
				if(y <= i)
				{
					i = y;
					n = n/10;
					sum = true;
				}
				else
				{
					sum = false;
					break outer;
				}
			}
		return sum;
	}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		Labprog7 lb =new Labprog7();
		boolean x = lb.checkNumber(n);
		System.out.println(x);
		System.exit(0);
		sc.close();
	}
}
