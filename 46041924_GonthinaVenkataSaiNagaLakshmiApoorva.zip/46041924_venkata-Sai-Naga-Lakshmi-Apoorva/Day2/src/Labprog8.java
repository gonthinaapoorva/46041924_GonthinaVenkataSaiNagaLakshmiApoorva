import java.util.*;
public class Labprog8 
{
	public boolean checkNumber(int n)
	{
		int i = 1;
		while(true)
		{
			i = i*2;
			if(i == n)
			{
				return true;
			}
			else if(i > n)
			{
				return false;
			}
		}
	}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		Labprog8 lb =new Labprog8();
		boolean x =lb.checkNumber(n);
		System.out.println(x);
		sc.close();
	}
}
