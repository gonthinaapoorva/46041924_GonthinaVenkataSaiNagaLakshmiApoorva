import java.util.*;
public class Labprog1 {
	int sum = 0;
	public void sum(int n)
	{
		while(n!=0)
		{
			int x = n % 10;
			n = n / 10;
			sum = sum + x*x*x;
		}
		System.out.println(sum);
	}
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		Labprog1 ob = new Labprog1();
		ob.sum(n);
		sc.close();
	}
}
