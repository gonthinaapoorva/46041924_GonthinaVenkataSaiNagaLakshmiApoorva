

public class Alldatatypes 
{
	byte a1;
	short a2;
	int a3;
	long a4;
	float a5;
	double a6;
	char a7;
	boolean a8;
	public void AllDataTypesInJava() 
	{
		System.out.println("Default values are ::==>");
		System.out.println(a1);
		System.out.println(a2);
		System.out.println(a3);
		System.out.println(a4);
		System.out.println(a5);
		System.out.println(a6);
		System.out.println(a7);
		System.out.println(a8);
		System.out.println("Ranges min to max");
		System.out.println("" + Byte.MIN_VALUE + " to "+ Byte.MAX_VALUE);
		System.out.println("" + Short.MIN_VALUE + " to "+ Short.MAX_VALUE);
		System.out.println("" + Integer.MIN_VALUE + " to "+ Integer.MAX_VALUE);
		System.out.println("" + Long.MIN_VALUE + " to "+ Long.MAX_VALUE);
		System.out.println("" + Float.MIN_VALUE + " to "+ Float.MAX_VALUE);
		System.out.println("" + Double.MIN_VALUE + " to "+ Double.MAX_VALUE);
		System.out.println("" + Character.MIN_VALUE + " to "+ Character.MAX_VALUE);
		System.out.println("Boolean have no min or max value");	
	}
	public static void main(String[] args) 
	{
		Alldatatypes al =new Alldatatypes();
		al.AllDataTypesInJava();
	}
}
