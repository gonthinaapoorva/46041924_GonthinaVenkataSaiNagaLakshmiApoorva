public class Prog4 
{
	int no1;
	int no2;
	public void Test() 
	{
		for(int i=0;i<20;i++) {
			System.out.println("i = "+i);
			System.out.println("no1 = " + no1);
			System.out.println("no2 = " +no2);
			no1++;
			no1 = no1 + 2;
			no1+= 3;
			System.out.println("no1 = " + no1);
			System.out.println("no2 = " +no2);
		}
	}
	public static void main(String args[]) {
		Prog4 ob = new Prog4();
		ob.Test();
	}
}
