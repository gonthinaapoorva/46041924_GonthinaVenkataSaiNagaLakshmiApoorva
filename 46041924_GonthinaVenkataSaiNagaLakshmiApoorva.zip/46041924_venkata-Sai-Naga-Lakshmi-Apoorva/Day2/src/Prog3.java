public class Prog3 
{
	
}
