
public class Prog5 {

}
