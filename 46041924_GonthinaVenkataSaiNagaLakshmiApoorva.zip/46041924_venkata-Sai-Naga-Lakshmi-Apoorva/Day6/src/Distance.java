public class Distance 
{
	public static void main(String args[])
	{
		long dist ;
		long speed = 18600;
		long days = 1000;
		long seconds = 86400;
		dist = speed * days * seconds;
		System.out.println("Distance:"+dist);
	}
}
