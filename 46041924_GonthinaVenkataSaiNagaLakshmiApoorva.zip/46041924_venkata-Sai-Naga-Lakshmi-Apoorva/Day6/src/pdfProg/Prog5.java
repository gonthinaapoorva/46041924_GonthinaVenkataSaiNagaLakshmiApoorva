package pdfProg;

public class Prog5 
{
	public static void main(String args[]) 
	{
		int[] array = new int[2];
		array[0]=20;
		array[1]=50;
		System.out.println(array[0]+":"+array[1]);
		int[] array1;
		array1 =new int[2];
		array1[0]=10;
		array1[1]=20;
		System.out.println(array1[0]+":"+array1[1]);
		
	}
}
