package pdfProg;

public class Prog1 
{
	static int s;
	int ns;
	Prog1(int ns)
	{
		if(s < ns)
		{
			s = ns;
			System.out.println("s=//"+s);
			this.ns = ns;
		}
	}
	void doPrint()
	{
		System.out.print("ns="+ns+"s="+s);
	}
	public static void main(String args[])
	{
		Prog1 p = new Prog1(50);
		Prog1 p1 = new Prog1(125);
		Prog1 p2 = new Prog1(100);
		p.doPrint();
		p1.doPrint();
		p2.doPrint();
		
	}
}
