package supclass;

class Sub 
{
	int varSuper= 4;
	public void supmtd()
	{
		System.out.println("Super method invoked");
	}
}
class Head extends Sub
{
	public void submtd()
	{
		super.supmtd();
		System.out.println("Sub class method invoked");
		System.out.println("Super class variable: "+super.varSuper);
	}
}

public class Mainjava
{
	public static void main(String args[])
	{
		Head m = new Head();
		m.submtd();
		 
	}
}

