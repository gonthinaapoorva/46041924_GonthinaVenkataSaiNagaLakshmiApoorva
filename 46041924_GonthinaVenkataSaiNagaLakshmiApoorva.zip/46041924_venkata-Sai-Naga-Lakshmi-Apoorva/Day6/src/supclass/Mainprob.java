package supclass;
import java.util.*;
class Details 
{
	Details(String fullname, String city, float salary)
	{
		System.out.println("Full name :" +fullname);
		System.out.println("city :" +city);
		System.out.println("salary :" +salary);
	}
}
public class Mainprob
{
	public static void main(String args[])
	{
		Scanner scanner = new Scanner(System.in);
		String fullname = scanner.nextLine();
		String city= scanner.nextLine();
		float salary= scanner.nextFloat();
		new Details(fullname,city,salary);
		scanner.close();
		
	}
}
