package otherpackage;

public class Sample
{

}
