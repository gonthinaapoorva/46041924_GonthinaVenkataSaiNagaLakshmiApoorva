package lab4;

public class Mainme 
{
	public static void main(String args[])
	{
		long accountNum = 11111111;
		double balance = 2000;
		Account a = new Account(accountNum,balance);
		accountNum = 22222222;
		balance = 3000;
		Account a1 = new Account(accountNum,balance);
		a1.withdraw(2000);
		System.out.println(a);
		System.out.println(a1);
	}
}
