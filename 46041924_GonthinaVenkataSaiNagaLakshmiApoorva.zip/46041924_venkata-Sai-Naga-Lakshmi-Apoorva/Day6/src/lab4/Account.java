package lab4;

public class Account 
{
	private long accountNum;
	private double balance;
	
	public Account(long accountNum,double balance)
	{
		this.accountNum=accountNum;
		this.balance=balance;
	}
	public void deposit(double amount)
	{
		double newbalance = balance + amount;
		setBalance(newbalance);
		
	}
	public void withdraw(double amount)
	{
		double newbalance = balance - amount;
		setBalance(newbalance);
	}
	public double getBalance()
	{
		return balance;
	}
	public long getaccountNum()
	{
		return accountNum;
	}
	public void setaccountNum(long accountNum)
	{
		this.accountNum=accountNum;
	}
	public void setBalance(double balance)
	{
		this.balance = balance;
	}
	public String toString()
	{
		return "Account No : " + getaccountNum() + "\n Balance : "+getBalance();
	}
}
