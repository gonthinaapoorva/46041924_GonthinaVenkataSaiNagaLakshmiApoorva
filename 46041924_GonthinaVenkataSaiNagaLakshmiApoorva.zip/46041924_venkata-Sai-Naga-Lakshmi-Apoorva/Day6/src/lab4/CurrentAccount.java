package lab4;

public class CurrentAccount extends Account
{
	int overdraftLimit= 1000;
}
