package lab4;

public class SavingAccount extends Account 
{
	public SavingAccount(long accountNum, double balance) {
		super(accountNum, balance);
		// TODO Auto-generated constructor stub
	}

	final double minimumBalance = 500;
	
	}

	

