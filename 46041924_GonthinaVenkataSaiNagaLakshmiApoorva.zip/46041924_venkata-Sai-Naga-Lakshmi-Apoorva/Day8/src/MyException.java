public class MyException extends Exception 
{ 
	
    public static void main(String args[]) 
    { 
    	int amount =0;
        try
        { 
            if(amount == 0) 
            {
            	throw new MyException(); 
            }
        } 
        catch (MyException ex) 
        { 
            System.out.println("Caught");  
        } 
    } 
} 