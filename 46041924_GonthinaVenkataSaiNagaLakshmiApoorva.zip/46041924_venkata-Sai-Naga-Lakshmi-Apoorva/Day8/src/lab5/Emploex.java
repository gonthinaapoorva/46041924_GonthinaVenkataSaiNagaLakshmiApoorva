package lab5;

import java.util.Scanner;

public class Emploex
{
	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the salary of the employee age: ");
		float salary = s.nextFloat();
		try
		{
			if(salary < 3000) 
			{
				throw new EmployeeException("The salary of the employee is below 3000");
			}
			else
			{
				System.out.println("Salary is above or equal to 3000");
			}
		}
		catch (EmployeeException a)
		{
			System.out.println(a);
		}
		s.close();
	 }
}
class EmployeeException extends Exception
{
	  public EmployeeException(String str)
	  {
		  System.out.println(str);
	  }
}

