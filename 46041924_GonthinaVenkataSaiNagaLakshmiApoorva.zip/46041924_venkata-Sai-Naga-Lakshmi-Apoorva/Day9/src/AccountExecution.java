import java.util.Scanner;
public class AccountExecution extends Account
{
		final double minBal=500;
		Person acH;
		double bal;
		int acN;
		AccountExecution(Person acH, int acN, double bal)
		{
			super(acH,acN,bal);
		}
		Scanner sc=new Scanner(System.in);
		public static void main(String[] args)
		{
			Person p1=new Person("Smith",48);
			Person p2=new Person("kathy",26);
			int acn1=(int)(Math.random()*10000);
			int acn2=(int)(Math.random()*10000);
			double bal1=2000;
			double bal2=3000;
			AccountExecution ae1=new AccountExecution(p1,acn1,bal1);
			AccountExecution ae2=new AccountExecution(p2,acn2,bal2);
			ae1.setAccHolder(p1);
			ae1.setAccNum(acn1);
			ae1.setBalance(bal1);
			ae2.setAccHolder(p2);
			ae2.setAccNum(acn2);
			ae2.setBalance(bal2);
			ae1.display();
			ae2.display();
			ae1.savings(bal1);
			ae2.savings(bal2);
			ae1.current(bal1);
			ae2.current(bal2);
		}
		public void display()
		{
			System.out.println(getAccHolder());
			System.out.println(getAccNum());
			System.out.println(getBalance());
		}
		public void savings(double bal)
		{
			if(bal<500)
			{
				System.out.println("The minimum balance should be 500.");
				System.exit(0);
			}
			else
			{
				System.out.println("Enter the amount to be deposited");
				double amount=sc.nextDouble();
				deposit(amount);
			}
		}
		public void current(double bal)
		{
			System.out.println("Enter the amount to be withdrawn: ");
			double amount1=sc.nextDouble();
			if(amount1>bal)
				System.out.println("amount exceeds balance amount");
			else
				withdraw(amount1);						
				
		}

	}

