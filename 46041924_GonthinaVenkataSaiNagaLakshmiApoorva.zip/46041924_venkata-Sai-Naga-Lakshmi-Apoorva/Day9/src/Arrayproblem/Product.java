package Arrayproblem;

public class Product {

}
