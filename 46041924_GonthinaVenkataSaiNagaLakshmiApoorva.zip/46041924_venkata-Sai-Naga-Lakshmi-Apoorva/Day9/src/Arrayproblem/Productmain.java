package Arrayproblem;

public class Productmain {

}
