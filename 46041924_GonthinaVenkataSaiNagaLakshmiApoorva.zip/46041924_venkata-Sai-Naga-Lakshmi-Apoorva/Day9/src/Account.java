public class Account
{
	private int accNum;
	private double balance;
	Person accHolder;
	
	Account(Person acH,int acN,double bal)
	{
		this.accHolder=acH;
		this.accNum=acN;
		this.balance=bal;
	}
	
	public long getAccNum()
	{
		return accNum;
	}
	public void setAccNum(int accNum)
	{
		this.accNum = accNum;
	}
	public double getBalance()
	{
		return balance;
	}
	public void setBalance(double balance)
	{
		this.balance = balance;
	}
	public Person getAccHolder()
	{
		return accHolder;
	}
	public void setAccHolder(Person accHolder)
	{
		this.accHolder = accHolder;
	}
	
	public void deposit(double amt)
	{
		balance=balance+amt;
		System.out.println("The amount has been deposited. Your current balance is "+balance);
	}
	public void withdraw(double amt)
	{
		double remaining=balance-amt;
		if(remaining<500)
			System.out.println("Sorry. You cannot withdraw as the minimum balance is 500.");
		else
		{
			balance=remaining;
			System.out.println("The amount has been withdrawn. The current balance is "+balance);
		}
				
	}
}


