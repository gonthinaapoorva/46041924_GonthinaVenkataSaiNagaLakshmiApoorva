
public interface EmployeeServices {
		public void getEmpDet();
		public String insScheme(float sal);
		public void dispEmp();
	}
