package collectionexample;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Collectionex
{
	public static void main(String args[]) 
	{
		
		List<String> list=new ArrayList<String>();
		
		// adding elements in list
		list.add("Apple");
		list.add("Mango");
		list.add("Banana");
		list.add("Custard apple");
		list.remove(1);// removing an element At index 1
		System.out.println(list);
		Iterator itr =list.iterator();  
		while(itr.hasNext())
		{  
			System.out.println(itr.next());  
		}     
		
		
		
		}

}

