package com.cg.Labprogram;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
	public static void main(String args[])
	{
		System.out.println("Start");
	    ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");
	    Employee emp = (Employee)context.getBean("emp");
	    System.out.println(emp.toString());
	}
}
