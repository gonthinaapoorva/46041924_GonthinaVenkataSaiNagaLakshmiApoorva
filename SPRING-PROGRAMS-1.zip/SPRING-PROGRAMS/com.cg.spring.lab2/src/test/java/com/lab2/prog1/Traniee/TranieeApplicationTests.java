package com.lab2.prog1.Traniee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranieeApplicationTests {

	@Test
	void contextLoads() {
	}

}
