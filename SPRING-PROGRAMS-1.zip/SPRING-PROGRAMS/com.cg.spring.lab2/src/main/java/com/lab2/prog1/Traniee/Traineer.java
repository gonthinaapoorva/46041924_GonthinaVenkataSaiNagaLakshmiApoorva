package com.lab2.prog1.Traniee;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Traineer {
	@Id
	@Column
	private int traineerId;
	@Column
	private String traineerName;
	@Column
	private String traineerDomain;
	@Column
	private String traineerLocation;
	
	public Traineer() {
		super();
	}
	
	public Traineer(int traineerId, String traineerName, String traineerDomain, String traineerLocation) {
		super();
		this.traineerId = traineerId;
		this.traineerName = traineerName;
		this.traineerDomain = traineerDomain;
		this.traineerLocation = traineerLocation;
	}

	public int getTraineerId() {
		return traineerId;
	}
	public void setTraineerId(int traineerId) {
		this.traineerId = traineerId;
	}
	public String getTraineerName() {
		return traineerName;
	}
	public void setTraineerName(String traineerName) {
		this.traineerName = traineerName;
	}
	public String getTraineerDomain() {
		return traineerDomain;
	}
	public void setTraineerDomain(String traineerDomain) {
		this.traineerDomain = traineerDomain;
	}
	public String getTraineerLocation() {
		return traineerLocation;
	}
	public void setTraineerLocation(String traineerLocation) {
		this.traineerLocation = traineerLocation;
	}
	
	
	

}
