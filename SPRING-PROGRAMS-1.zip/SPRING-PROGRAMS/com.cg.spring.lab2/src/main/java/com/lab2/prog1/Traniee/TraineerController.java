package com.lab2.prog1.Traniee;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class TraineerController 
{
		@Autowired
		TraineerService traineerService;
		
		// insert Trainee
		@PostMapping("/Tra")
		public int AddTraineer(@RequestBody Traineer traineer)
		{
			traineerService.saveTraineer(traineer);
			return traineer.getTraineerId();
		}
		
		
		//Update Trainee
		@PutMapping("/Tra")
		public Traineer Update(@RequestBody Traineer traineer)
		{
			traineerService.updateTraineer(traineer);
			return traineer;
		}
		
		
		//delete Trainee
		@DeleteMapping("/Tra/{traineerId}")
		public void remove(@PathVariable("traineerId") int traineerId)
		{
			traineerService.delete(traineerId);
		}
		
	
		// retrieve trainee by particular Id
		@GetMapping("/Tra/{traineerId}")
		public Traineer getTraineer(@PathVariable("traineerId") int traineerId)
		{
			return traineerService.getTraineerById(traineerId);
		}
		
		// retrieve traniee by particular name
		
		@GetMapping("/Traineer/{traineerName}")
		public List<Traineer> getTraineeByName(@PathVariable("traineerName") String traineerName)
		{
			return traineerService.getTraineeByName(traineerName);
		}
		
		
		//Get all employees
		
			@GetMapping("/Tra")
			public List<Traineer> getAllTraineer()
			{
				return traineerService.getAllTraineer();
			}

}