package com.lab2.prog1.Traniee;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lab2.prog1.Traniee.TraineerRepository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TraineerService {
	@Autowired
 	TraineerRepository traineerRepository;
 
 	public List<Traineer> getAllTraineer() 
 	{
       	List<Traineer> traineer = new ArrayList<Traineer>();
       traineerRepository.findAll().forEach(traineer1 -> traineer.add(traineer1));
       	return traineer;
 	}
 	public Traineer getTraineerById(int traineerId) {
       	return traineerRepository.findById(traineerId).get();
 	}

 	public List<Traineer> getTraineeByName(String traineerName) {
		List<Traineer> trainees=new ArrayList<Traineer>();
		traineerRepository.findAll().forEach(trainee1->trainees.add(trainee1));
		List<Traineer> nameList=new ArrayList<Traineer>();
		for(Traineer t: trainees)
		{
			if(t.getTraineerName().equalsIgnoreCase(traineerName))
				nameList.add(t);	
		}
		return nameList;
	}
 	
 	public void saveTraineer(Traineer traineer) {
       	traineerRepository.save(traineer);
 	}
 

 	public void delete(int traineerId) {
       	traineerRepository.deleteById(traineerId);
 	}
 
 	public void updateTraineer(Traineer traineer) {
       	traineerRepository.save(traineer);
 	}
}