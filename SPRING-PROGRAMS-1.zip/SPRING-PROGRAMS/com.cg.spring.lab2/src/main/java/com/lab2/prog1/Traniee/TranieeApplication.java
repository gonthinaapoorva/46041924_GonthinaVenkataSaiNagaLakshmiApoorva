package com.lab2.prog1.Traniee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TranieeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TranieeApplication.class, args);
	}

}
