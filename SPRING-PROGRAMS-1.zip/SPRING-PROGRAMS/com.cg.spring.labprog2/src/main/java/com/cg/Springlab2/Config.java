package com.cg.Springlab2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config 
{
	@Bean
	public Employee emp()
	{
		SBU sbu=new SBU("PES_BU","Kiran Rao","Product Engineering Services");
		Employee emp = new Employee(12345,"Harriet",40000,sbu);
		return emp;
	}
	
	@Bean
	public SBU sbu()
	{
		return new SBU();
	}
}
