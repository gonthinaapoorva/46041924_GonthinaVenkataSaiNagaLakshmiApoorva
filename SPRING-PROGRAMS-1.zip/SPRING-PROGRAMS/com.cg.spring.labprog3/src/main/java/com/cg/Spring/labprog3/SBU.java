package com.cg.Spring.labprog3;

import java.util.List;

public class SBU 
{
	private String sbuCode;
	private String sbuHead;
	private String sbuName;
	private List<Employee> emplist;
	public SBU() {
		super();
	}
	
	public SBU(String sbuCode, String sbuHead, String sbuName,List<Employee> emplist) {
		super();
		this.sbuCode = sbuCode;
		this.sbuHead = sbuHead; 
		this.sbuName = sbuName;
		this.emplist=emplist;
	}

	public String getSbuCode() {
		return sbuCode;
	}
	public void setSbuCode(String sbuCode) {
		this.sbuCode = sbuCode;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	
	public List<Employee> getEmplist() {
		return emplist;
	}

	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}

	@Override
	public String toString() {
		return "SBU [sbuCode=" + sbuCode + ", sbuHead=" + sbuHead + ", sbuName=" + sbuName + ", emplist=" + emplist
				+ "]";
	}
	
}
