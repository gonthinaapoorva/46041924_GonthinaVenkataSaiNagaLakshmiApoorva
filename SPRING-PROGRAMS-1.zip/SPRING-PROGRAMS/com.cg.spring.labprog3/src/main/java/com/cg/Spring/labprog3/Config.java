package com.cg.Spring.labprog3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config 
{
	
	
	@Bean
	public SBU sbu()
	{
		Employee emp1= new Employee(100, "Rama", 12345.67);
		Employee emp2=new Employee(101, "kama", 12345.67);
		List<Employee> li = new ArrayList<Employee>();
		li.add(emp1);
		li.add(emp2);
		return new SBU("PES-BU","Kiran rao","Product Emgineering Services",li );
	}
	@Bean
	public Employee emp()
	{
		return new Employee();
	}
	
}
